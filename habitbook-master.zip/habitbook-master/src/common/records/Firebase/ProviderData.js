// @flow

export type ProviderData = Array<any>
