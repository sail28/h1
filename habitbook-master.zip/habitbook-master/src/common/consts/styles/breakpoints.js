export const small = '(min-width: 600px)'
export const medium = '(min-width: 960px)'
export const large = '(min-width: 1280px)'
export const xLarge = '(min-width: 1920px)'
